using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace DLLInjectorUI
{
    public partial class Form1 : Form
    {
        private int selectedProcessId = -1;

        [DllImport("kernel32.dll")]
        private static extern IntPtr OpenProcess(int processAccess, bool bInheritHandle, int processId);

        [DllImport("kernel32.dll")]
        private static extern IntPtr VirtualAllocEx(IntPtr hProcess, IntPtr lpAddress, uint dwSize, uint flAllocationType, uint flProtect);

        [DllImport("kernel32.dll")]
        private static extern bool WriteProcessMemory(IntPtr hProcess, IntPtr lpBaseAddress, byte[] lpBuffer, uint dwSize, out int lpNumberOfBytesWritten);

        [DllImport("kernel32.dll")]
        private static extern IntPtr CreateRemoteThread(IntPtr hProcess, IntPtr lpThreadAttributes, uint dwStackSize, IntPtr lpStartAddress, IntPtr lpParameter, uint dwCreationFlags, out uint dwThreadId);

        [DllImport("kernel32.dll")]
        private static extern bool CloseHandle(IntPtr hObject);

        private const int PROCESS_ALL_ACCESS = 0x1F0FFF;
        private const uint MEM_COMMIT = 0x1000;
        private const uint MEM_RESERVE = 0x2000;
        private const uint PAGE_EXECUTE_READWRITE = 0x40;

        public Form1()
        {
            InitializeComponent();
            LoadProcesses();
        }

        private void LoadProcesses()
        {
            ProcessList.Items.Clear();
            foreach (var process in Process.GetProcesses())
            {
                ProcessList.Items.Add($"{process.ProcessName}.exe ({process.Id})");
            }
        }

        private void InjectButton_Click(object sender, EventArgs e)
        {
            if (selectedProcessId == -1)
            {
                MessageBox.Show("Please select a process to inject the DLL.");
                return;
            }

            string dllPath = DLLPathTextBox.Text;
            if (string.IsNullOrEmpty(dllPath))
            {
                MessageBox.Show("Please select a DLL to inject.");
                return;
            }

            IntPtr hProcess = OpenProcess(PROCESS_ALL_ACCESS, false, selectedProcessId);
            if (hProcess == IntPtr.Zero)
            {
                MessageBox.Show("Failed to open process.");
                return;
            }

            IntPtr allocMemAddress = VirtualAllocEx(hProcess, IntPtr.Zero, (uint)dllPath.Length + 1, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
            if (allocMemAddress == IntPtr.Zero)
            {
                CloseHandle(hProcess);
                MessageBox.Show("Failed to allocate memory in the target process.");
                return;
            }

            byte[] dllPathBytes = System.Text.Encoding.ASCII.GetBytes(dllPath);
            if (!WriteProcessMemory(hProcess, allocMemAddress, dllPathBytes, (uint)dllPathBytes.Length, out int bytesWritten))
            {
                CloseHandle(hProcess);
                MessageBox.Show("Failed to write to process memory.");
                return;
            }

            IntPtr hKernel32 = GetModuleHandle("kernel32.dll");
            IntPtr hLoadLibrary = GetProcAddress(hKernel32, "LoadLibraryA");
            if (hLoadLibrary != IntPtr.Zero)
            {
                CreateRemoteThread(hProcess, IntPtr.Zero, 0, hLoadLibrary, allocMemAddress, 0, out _);
            }

            CloseHandle(hProcess);
            MessageBox.Show("DLL injected successfully!");
        }

        private void BrowseDLLButton_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.Filter = "DLL Files (*.dll)|*.dll";
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    DLLPathTextBox.Text = openFileDialog.FileName;
                }
            }
        }

        private void ProcessSelectButton_Click(object sender, EventArgs e)
        {
            if (ProcessList.SelectedItem != null)
            {
                string selectedProcess = ProcessList.SelectedItem.ToString();
                string processIdString = selectedProcess.Split('(')[1].Split(')')[0];
                selectedProcessId = int.Parse(processIdString);
                MessageBox.Show($"Selected process ID: {selectedProcessId}");
            }
            else
            {
                MessageBox.Show("Please select a process from the list.");
            }
        }

        private void DLLPathTextBox_TextChanged(object sender, EventArgs e)
        {
            // You can add any additional logic here if needed
        }

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern IntPtr GetModuleHandle(string lpModuleName);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern IntPtr GetProcAddress(IntPtr hModule, string lpProcName);

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
