﻿namespace DLLInjectorUI
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            BrowseDLLButton = new Button();
            DLLPathTextBox = new TextBox();
            ProcessList = new ComboBox();
            ProcessSelectButton = new Button();
            InjectButton = new Button();
            SuspendLayout();
            // 
            // BrowseDLLButton
            // 
            BrowseDLLButton.Location = new Point(257, 10); // Adjusted position
            BrowseDLLButton.Name = "BrowseDLLButton";
            BrowseDLLButton.Size = new Size(75, 23);
            BrowseDLLButton.TabIndex = 0;
            BrowseDLLButton.Text = "Browse";
            BrowseDLLButton.UseVisualStyleBackColor = true;
            BrowseDLLButton.Click += BrowseDLLButton_Click;
            // 
            // DLLPathTextBox
            // 
            DLLPathTextBox.Location = new Point(12, 10); // Adjusted position
            DLLPathTextBox.Name = "DLLPathTextBox";
            DLLPathTextBox.ReadOnly = true;
            DLLPathTextBox.Size = new Size(239, 23);
            DLLPathTextBox.TabIndex = 3;
            DLLPathTextBox.Text = "Please Select DLL";
            DLLPathTextBox.TextChanged += DLLPathTextBox_TextChanged;
            // 
            // ProcessList
            // 
            ProcessList.FormattingEnabled = true;
            ProcessList.Location = new Point(12, 39); // Adjusted position
            ProcessList.Name = "ProcessList";
            ProcessList.Size = new Size(239, 23);
            ProcessList.TabIndex = 4;
            ProcessList.Text = "Select Process";
            // 
            // ProcessSelectButton
            // 
            ProcessSelectButton.Location = new Point(257, 39); // Adjusted position
            ProcessSelectButton.Name = "ProcessSelectButton";
            ProcessSelectButton.Size = new Size(75, 23);
            ProcessSelectButton.TabIndex = 5;
            ProcessSelectButton.Text = "Select";
            ProcessSelectButton.UseVisualStyleBackColor = true;
            ProcessSelectButton.Click += ProcessSelectButton_Click;
            // 
            // InjectButton
            // 
            InjectButton.Location = new Point(12, 68); // Adjusted position
            InjectButton.Name = "InjectButton";
            InjectButton.Size = new Size(320, 23);
            InjectButton.TabIndex = 6;
            InjectButton.Text = "Inject";
            InjectButton.UseVisualStyleBackColor = true;
            InjectButton.Click += InjectButton_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(343, 104);
            Controls.Add(InjectButton);
            Controls.Add(ProcessSelectButton);
            Controls.Add(ProcessList);
            Controls.Add(DLLPathTextBox);
            Controls.Add(BrowseDLLButton);
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "DLL Injector (64-bit)";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button BrowseDLLButton;
        private TextBox DLLPathTextBox;
        private ComboBox ProcessList;
        private Button ProcessSelectButton;
        private Button InjectButton;
    }
}
